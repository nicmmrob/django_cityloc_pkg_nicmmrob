from django.apps import AppConfig


class CitylocationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'citylocations'
